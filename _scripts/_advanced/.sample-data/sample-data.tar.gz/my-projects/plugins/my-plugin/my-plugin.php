<?php
/**
 * Plugin Name: My Plugin Demo
 * Plugin URI: https://techreader.com
 * Description: Demo for screenshots of fast deploy app
 * Version: 1.0.3
 * Author: TechReader
 * Text Domain: my-plugin
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('TR_MY_PLUGIN_VERSION', '1.0.3');
?>
