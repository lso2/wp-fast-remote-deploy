Upload this file to your root, and run it over ssh:

	cd /path/to/detect-server-config.sh

It will create a file in the same folder with your server details!